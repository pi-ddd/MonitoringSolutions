NetsnmpCacheLoad netsnmp_sensor_arch_load;
void             netsnmp_sensor_arch_init(void);
