void init_hw_mem(void);
