void init_cpu(void);
void shutdown_cpu(void);
