extern void netsnmp_arch_swrun_init(void);
extern int netsnmp_arch_swrun_container_load(netsnmp_container* container,
                                             u_int load_flags);
